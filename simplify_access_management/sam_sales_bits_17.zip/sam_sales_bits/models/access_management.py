from odoo import fields, models, api, _
from odoo.http import request

class access_management(models.Model):
    _inherit = 'access.management'

    def ishide_sale_product_ext_link(self):
            # Return True if hide / return False if not hide
            hide_field_obj = self.env['hide.field'].sudo()
            hide_ext_link = False
            for hide_field in hide_field_obj.search(
                            [('access_management_id.company_ids', 'in', self.env.company.id),
                            ('model_id.model', '=', 'sale.order.line'), ('access_management_id.active', '=', True),
                            ('access_management_id.user_ids', 'in', request.env.uid)]):
                for field_id in hide_field.field_id:
                    if hide_field.external_link:
                        hide_ext_link = True
            return hide_ext_link

    def get_sale_line_access(self):
        hide_field_obj = self.env['hide.field'].sudo() 
        hide_ext_link = False
        hide_prod_create = True
        hide_prod_create_edit = True
        for hide_field in hide_field_obj.search(
                            [('access_management_id.company_ids', 'in', self.env.company.id),
                            ('model_id.model', '=', 'sale.order.line'), ('access_management_id.active', '=', True),
                            ('access_management_id.user_ids', 'in', request.env.uid)]):
                for field_id in hide_field.field_id:
                    if hide_field.external_link:
                        hide_ext_link = True
                    if 'create_option' in hide_field_obj._fields and 'edit_option' in hide_field_obj._fields:
                        if hide_field.create_option:
                            hide_prod_create = False
                        if hide_field.edit_option:
                            hide_prod_create_edit = False
                    else:
                        hide_prod_create = False
                        hide_prod_create_edit = False
        res = {'hide_prod_ext_link': hide_ext_link, 'hide_prod_create':hide_prod_create, 'hide_prod_create_edit':hide_prod_create_edit}
        return res


   