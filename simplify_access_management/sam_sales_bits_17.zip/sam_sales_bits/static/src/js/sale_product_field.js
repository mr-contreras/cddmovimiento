/** @odoo-module **/
import { SaleOrderLineProductField } from "@sale/js/sale_product_field";
import { Many2XAutocomplete } from "@web/views/fields/relational_utils";
import { patch } from "@web/core/utils/patch";
import {onWillStart, useState } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation"; 
import { RPCError } from "@web/core/network/rpc_service"; 

patch(SaleOrderLineProductField.prototype, {
    setup(){
        super.setup();
        this.access = useState({
            hide_prod_ext_link: false,
            hide_prod_create:false,
            hide_prod_create_edit:false,
            write:false
        });
        onWillStart(async() => {
            let sam_access = await this.orm.call(
                "access.management",
                "get_sale_line_access",
                [[]]
            ); 
            if(sam_access){
                this.access.hide_prod_ext_link = sam_access.hide_prod_ext_link;
                this.access.hide_prod_create = sam_access.hide_prod_create;
                this.access.hide_prod_create_edit = sam_access.hide_prod_create_edit;
                this.access.write = sam_access.write;
            }
        });
    },
    get hasExternalButton() {
        const res = super.hasExternalButton; 
        if(res && !this.access.hide_prod_ext_link){
            return true;
        }else if(res && this.access.hide_prod_ext_link){
            return false;
        } 
        else{
            return res
        }
    },
    get Many2XAutocompleteProps() {
        const res = super.Many2XAutocompleteProps; 
        if(res){
            console.log(this.access);
            console.log('access this.access');

            res.activeActions.create = this.access.hide_prod_create;
            res.activeActions.createEdit = this.access.hide_prod_create_edit;
            res.activeActions.write = this.access.write;
        }
        return res;
    }
});
patch(Many2XAutocomplete.prototype, {
    async loadOptionsSource(request) {
        if (this.lastProm) {this.lastProm.abort(false);}
        this.lastProm = this.search(request);
        const records = await this.lastProm;

        const options = records.map((result) => this.mapRecordToOption(result));
        const canCreate = "create" in this.props.activeActions ? this.props.activeActions.create: true;
        console.log(this.props.activeActions);
        const canCreateEdit =
            "createEdit" in this.activeActions
                ? this.activeActions.createEdit
                : this.activeActions.create;
        // added extra condition to check if create is allowed or not
        if (canCreate && this.props.quickCreate && request.length) {
            options.push({
                label: _t('Create "%s"', request),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_create",
                action: async (params) => {
                    try {
                        await this.props.quickCreate(request, params);
                    } catch (e) {
                        if (
                            e instanceof RPCError &&
                            e.exceptionName === "odoo.exceptions.ValidationError"
                        ) {
                            const context = this.getCreationContext(request);
                            return this.openMany2X({ context });
                        }
                        throw e;
                    }
                },
            });
        }

        if (!this.props.noSearchMore && records.length > 0) {
            options.push({
                label: _t("Search More..."),
                action: this.onSearchMore.bind(this, request),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_search_more",
            });
        }
 
        if (!request.length && !this.props.value && (this.props.quickCreate || canCreateEdit)) {
            options.push({
                label: _t("Start typing..."),
                classList: "o_m2o_start_typing",
                unselectable: true,
            });
        } 
        if (request.length && canCreateEdit) {
            const context = this.getCreationContext(request);
            options.push({
                label: _t("Create and edit..."),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_create_edit",
                action: () => this.openMany2X({ context }),
            });
        }

        if (!records.length && !this.activeActions.createEdit && !this.props.quickCreate) {
            options.push({
                label: _t("No records"),
                classList: "o_m2o_no_result",
                unselectable: true,
            });
        }

        return options;
    }
});
